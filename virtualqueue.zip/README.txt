TO USE IT:-
This is a django project which has an app named cuqueue.
To run it , use following steps:-
In terminal go to project folder which is Vq.
run command:-python3 manage.py runserver
 
For accountant :- 127.0.0.1:8000/home/login .
Here by putting username(cucoderarmy) and password(cu67506693) we can access the list of students who have created token.

..........................................................................................................................................................
..........................................................................................................................................................
Name of project:- Virtual Queue
Discription :- 
In our university students have to stand in  queue for long time to pay their fees. This waste alot of their time and may are not able to attend classes due to it. 
So our idea is to create a virtual queue. 
In the fee section of cuims there could be an option for creating a virtual token (appontment), when one will do so he/she will get a time,queue number via email and same will be flashed on the screen. So they can go on the appointed time and pay theri fee directly without waiting in a queue. 

  VIRTUAL QUEUE

On Student Side:-

     “Generate Virtual Token” option will be given in CUIMS Online Payment Section.
    When clicked/chosen the option:-

             i)  Student will get a Virtual Token THEN and THERE on CUIMS 

                        account.

             ii)  A message will  be send to the teacher having period at that time  

                                     with

                     NAME/UID/TOKEN/TIME

On Fee Counter Side:-

  1)  There will be a list of Students with QUEUE No./NAME/UID/TIME.

  2) There will be a check box in front of every row.

  3)   We just need to check that box to clear the fee of particular student.

  4)   After all are cleared a report will be generated showing total deposit/No. 

              Of Student  Deposited fee.
Team Members:-
Karan Jakhar 17BCS1647 (CSE)
Harnoor Singh 17BCS1746 (CSE)
karanjakhar4@gmail.com
noorsingh6693@gmail.com


