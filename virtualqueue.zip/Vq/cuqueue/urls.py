from . import views
from django.conf.urls import url
urlpatterns = [


    url(r'^reset',views.reset,name='reset'),
    url(r'^login',views.login_page,name='login'),
    url(r'^staff',views.staff,name='staff'),
    url(r'^total',views.total,name='total'),
]
