from django.shortcuts import render, redirect
from .form import NameForm,staffform
from django.urls import reverse

from cuqueue.models import details

from django.contrib.auth import authenticate,login



def index(request):
    pass


def lists(request):
    get_it = details.objects.all()
    return render(request, "cuqueue/list.html", {"get_it": get_it})

def login_page(request):
    form=staffform()
    return render(request,"cuqueue/staff_login.html",{'form':form})

def staff(request):
    username=request.POST['username']
    password=request.POST['password']
    user=authenticate(request,username=username,password=password)
    if user is not None:
        login(request,user)
        return lists(request)

    else:
        return redirect(reverse('login'))

def total(request):
    pass
    #return render(request,'cuqueue/total.html')


def reset(request):
    global min_ch
    global q_no
    min_ch=0
    q_no=0
    data = details.objects.all()
    data.delete()

