from django.contrib import admin
from .models import details

admin.site.register(details)

