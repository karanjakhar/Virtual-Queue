from django.apps import AppConfig


class CuqueueConfig(AppConfig):
    name = 'cuqueue'
